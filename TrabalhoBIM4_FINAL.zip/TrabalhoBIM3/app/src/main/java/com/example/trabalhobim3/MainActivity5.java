package com.example.trabalhobim3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity5 extends AppCompatActivity {

    ListView lvGamer;
    TextView tvGamer;
    ArrayList<Gamer> arrayGamer;
    ArrayList<String> arrayDadosGamer;
    ArrayAdapter<String> dadosAdapterGamer;
    Intent intent;
    int pos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        lvGamer = findViewById(R.id.lv_gamer);
        tvGamer = findViewById(R.id.tv_Gamer);
        arrayGamer = MainActivity2.arrayGamer;
        intent = getIntent();
        arrayDadosGamer = intent.getStringArrayListExtra("dadosGamer");
        pos = intent.getIntExtra("refPosicao", -1);
        tvGamer.setText(arrayGamer.get(pos).getEmail());
        dadosAdapterGamer = new ArrayAdapter<>(this,
                R.layout.support_simple_spinner_dropdown_item, arrayDadosGamer);
        lvGamer.setAdapter(dadosAdapterGamer);

    }

    public void voltar(View View){
        intent = new Intent(MainActivity5.this, MainActivity6.class);
        startActivity(intent);
    }

    public void excluir(View View){
        arrayGamer.remove(pos);
        intent = new Intent(MainActivity5.this, MainActivity3.class);
        startActivity(intent);
    }

    public void verLista(View View){
        intent = new Intent(MainActivity5.this, MainActivity3.class);
        startActivity(intent);
    }

}