package com.example.trabalhobim3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {

    EditText etNome, etIdade, etEmail, etTelefone, etSenha,
            etConfirma, etCPF;
    Spinner spnUf;
    CheckBox cbAventura, cbModa, cbTerror, cbOutros;
    public static ArrayList<Gamer> arrayGamer = new ArrayList<>();
    ArrayAdapter<Gamer> adapterGamer;
    Intent i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        etNome = findViewById(R.id.etNome);
        etIdade = findViewById(R.id.etIdade);
        etEmail = findViewById(R.id.etEmail);
        etTelefone = findViewById(R.id.etTelefone);
        spnUf = findViewById(R.id.spnUf);
        etSenha = findViewById(R.id.etSenha);
        etConfirma = findViewById(R.id.etConfirma);
        cbAventura = findViewById(R.id.cbAventura);
        cbModa = findViewById(R.id.cbModa);
        cbTerror = findViewById(R.id.cbTerror);
        cbOutros = findViewById(R.id.cbOutros);
        etCPF = findViewById(R.id.etCPF);
    }

    public void cadastrar(View View) {

        ArrayList<String> categorias = new ArrayList<>();

        if (etNome.getText().toString().isEmpty()
                && etIdade.getText().toString().isEmpty() && etEmail.getText().toString().isEmpty()
                && etTelefone.getText().toString().isEmpty()
                && !cbAventura.isChecked() && !cbModa.isChecked() && !cbTerror.isChecked()
                && !cbOutros.isChecked() && spnUf.getSelectedItemPosition() == 0
                && etCPF.getText().toString().isEmpty()) {

            Toast.makeText(this, "Preencha todos os dados corretamente para prosseguir!",
                    Toast.LENGTH_SHORT).show();
        } else {
            if (etNome.getText().toString().isEmpty()) {
                Toast.makeText(this, "Preecha o nome para prosseguir!",
                        Toast.LENGTH_SHORT).show();
            } else if (etIdade.getText().toString().isEmpty()) {
                Toast.makeText(this, "Preencha a idade para prosseguir!",
                        Toast.LENGTH_SHORT).show();
            } else {
                int idade = Integer.parseInt(etIdade.getText().toString());

                if (idade < 12) {
                    Toast.makeText(this, "Você é menor de idade, não poderá prosseguir com o cadastro!",
                            Toast.LENGTH_LONG).show();
                } else if (etCPF.getText().toString().isEmpty()) {
                    Toast.makeText(this, "Preencha o CPF, para prosseguir!",
                            Toast.LENGTH_SHORT).show();
                } else if (etEmail.getText().toString().isEmpty()) {
                    Toast.makeText(this, "Preencha o email para prosseguir!",
                            Toast.LENGTH_SHORT).show();
                } else if (etTelefone.getText().toString().isEmpty()) {
                    Toast.makeText(this, "Preencha o telefone para prosseguir!",
                            Toast.LENGTH_SHORT).show();
                } else if (spnUf.getSelectedItemPosition() == 0) {
                    Toast.makeText(this, "Escolha um estado para prosseguir!",
                            Toast.LENGTH_SHORT).show();
                } else if (!cbAventura.isChecked() && !cbModa.isChecked()
                        && !cbTerror.isChecked() && !cbOutros.isChecked()) {
                    Toast.makeText(this, "Escolha uma categoria para prosseguir!",
                            Toast.LENGTH_SHORT).show();
                } else {
                    if (cbAventura.isChecked())
                        categorias.add(cbAventura.getText().toString());

                    if (cbModa.isChecked())
                        categorias.add(cbModa.getText().toString());

                    if (cbTerror.isChecked())
                        categorias.add(cbTerror.getText().toString());

                    if (cbOutros.isChecked())
                        categorias.add(cbOutros.getText().toString());

                    if (etSenha.getText().toString().isEmpty()) {
                        Toast.makeText(this, "Preencha a senha para prosseguir!",
                                Toast.LENGTH_SHORT).show();
                    } else if (etConfirma.getText().toString().isEmpty()) {
                        Toast.makeText(this, "Preencha a confirmação de senha para prosseguir!",
                                Toast.LENGTH_SHORT).show();
                    } else {
                        String senha = etSenha.getText().toString();
                        String confirmacaoSenha = etConfirma.getText().toString();

                        if (!senha.equals(confirmacaoSenha)) {
                            Toast.makeText(this, "Digite corretamente os dois campos de senha!", Toast.LENGTH_LONG).show();

                        } else { //verificar email igual
                            String nome = etNome.getText().toString();
                            idade = Integer.parseInt(etIdade.getText().toString());
                            String email = etEmail.getText().toString();
                            String telefone = etTelefone.getText().toString();
                            String cpf = etCPF.getText().toString();
                            String uf = spnUf.getSelectedItem().toString();

                            Gamer gamer = new Gamer(nome, email, telefone, cpf, uf, idade, categorias, senha);
                            arrayGamer.add(gamer);
                            adapterGamer= new ArrayAdapter<>(this,
                                    androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, arrayGamer);

                            Toast.makeText(this, "Cadastro Realizado com Sucesso!!!", Toast.LENGTH_SHORT).show();

                            Intent i = new Intent(MainActivity2.this, MainActivity6.class);
                            startActivity(i);

                        }
                    }
                }
            }
        }
    }

    public void limpar (View View){
        etNome.setText("", null);
        etIdade.setText("", null);
        etEmail.setText("", null);
        etTelefone.setText("", null);
        etCPF.setText("", null);
        spnUf.setSelection(0);
        cbAventura.setChecked(false);
        cbModa.setChecked(false);
        cbTerror.setChecked(false);
        cbOutros.setChecked(false);
    }

    public void voltar (View View){
        i = new Intent(MainActivity2.this, MainActivity6.class);
        startActivity(i);
    }
}