package com.example.trabalhobim3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Intent i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // cadastra dois users no banco (admin e isabela)
        ArrayList<Gamer> arrayGamer = MainActivity2.arrayGamer;

        ArrayList<String> categorias = new ArrayList<>();
        categorias.add("Terror");

        Gamer admin = new Gamer();
        admin.setNome("Administrador");
        admin.setEmail("admin");
        admin.setTelefone("19991174243");
        admin.setCpf("125461886");
        admin.setUf("SP");
        admin.setIdade(18);
        admin.setCategorias(categorias);
        admin.setSenha("123");

        Gamer isa = new Gamer();
        isa.setNome("Isabela");
        isa.setEmail("isa");
        isa.setTelefone("19991174243");
        isa.setCpf("125461886");
        isa.setUf("SP");
        isa.setIdade(20);
        isa.setCategorias(categorias);
        isa.setSenha("20");

        //arrayGamer = new ArrayList<>();
        arrayGamer.add(admin);
        arrayGamer.add(isa);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(MainActivity.this, MainActivity6.class);
                startActivity(i);
            }
        }, 5000);
    }
}