package com.example.trabalhobim3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity6 extends AppCompatActivity {
    
    EditText email, senha;
    ArrayList<Gamer> arrayGamer;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
        
        email = findViewById(R.id.email);
        senha = findViewById(R.id.senha);

        arrayGamer = MainActivity2.arrayGamer;

    }
    
    public void entrar(View v) {

        String emailS = email.getText().toString();
        String senhaS = senha.getText().toString();

        if(emailS.isEmpty() || senhaS.isEmpty()){
            Toast.makeText(this, "Preencha os campos corretamente", Toast.LENGTH_SHORT).show();
        }else{
            for (int i = 0; i < arrayGamer.size(); i++){
                if(emailS.equals(arrayGamer.get(i).getEmail()) && senhaS.equals(arrayGamer.get(i).getSenha())) {
                    if(arrayGamer.get(i).getEmail().equals("admin") && arrayGamer.get(i).getSenha().equals("123")){
                        intent = new Intent(MainActivity6.this, MainActivity3.class);
                        startActivity(intent);
                        return;
                    } else{
                        ArrayList<String> dadosGamer = new ArrayList<>();
                        dadosGamer.add(arrayGamer.get(i).getNome());
                        dadosGamer.add(arrayGamer.get(i).getEmail());
                        dadosGamer.add(arrayGamer.get(i).getTelefone());
                        dadosGamer.add(arrayGamer.get(i).getCpf());
                        dadosGamer.add(String.valueOf(arrayGamer.get(i).getIdade()));

                        String cat = "";

                        // inicio da caminhada; fim da caminhada; modo de caminhar
                        for (int index = 0; index < arrayGamer.get(i).getCategorias().size(); index++){
                            if ( index > 0) {
                                if (index == arrayGamer.get(i).getCategorias().size()-2)
                                    cat += arrayGamer.get(i).getCategorias().get(index).toLowerCase() + " e ";

                                else
                                if (i == arrayGamer.get(i).getCategorias().size()-1)
                                    cat += arrayGamer.get(i).getCategorias().get(index).toLowerCase();
                                else
                                    cat += arrayGamer.get(i).getCategorias().get(index).toLowerCase() + ", ";
                            }
                            else{
                                if (i == arrayGamer.get(i).getCategorias().size()-2)
                                    cat += arrayGamer.get(i).getCategorias().get(index) + " e ";

                                else
                                if (i == arrayGamer.get(i).getCategorias().size()-1)
                                    cat += arrayGamer.get(i).getCategorias().get(index);
                                else
                                    cat += arrayGamer.get(i).getCategorias().get(index);
                            }
                        }

                        dadosGamer.add(cat);
                        dadosGamer.add(arrayGamer.get(i).getSenha());

//                        Gamer g = new Gamer();
//                        g.setNome(arrayGamer.get(i).getNome());
//                        g.setEmail(arrayGamer.get(i).getEmail());
//                        g.setTelefone(arrayGamer.get(i).getTelefone());
//                        g.setCpf(arrayGamer.get(i).getCpf());
//                        g.setIdade(arrayGamer.get(i).getIdade());
//                        g.setCategorias(arrayGamer.get(i).getCategorias());
//                        g.setSenha(arrayGamer.get(i).getSenha());

                        intent = new Intent(MainActivity6.this, MainActivity5.class);
                        intent.putStringArrayListExtra("dadosGamer", dadosGamer);
                        intent.putExtra("refPosicao", i);
                        startActivity(intent);
                        return;
                    }

                }
            }
            Toast.makeText(this, "Você não possui cadastro. Cadastre-se primeiro.", Toast.LENGTH_SHORT).show();
            }
        }

    public void cadastro(View v){
        intent = new Intent(MainActivity6.this, MainActivity2.class);
        startActivity(intent);
    }

    public void login(View v){
         intent = new Intent(MainActivity6.this, MainActivity6.class);
        startActivity(intent);
    }

    public void info(View v){
        intent = new Intent(MainActivity6.this, MainActivity4.class);
        startActivity(intent);
    }

}