package com.example.trabalhobim3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity3 extends AppCompatActivity {

    ListView lvgamer;
    ArrayList<Gamer> arrayGamer;
    ArrayList<String> arrayDadosGamer;
    ArrayAdapter<Gamer> adapterGamer;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);


        intent = getIntent();
        lvgamer = findViewById(R.id.lv_gamer);
        arrayGamer = MainActivity2.arrayGamer;
        adapterGamer = new ArrayAdapter<>(this,
                androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, arrayGamer);
        lvgamer.setAdapter(adapterGamer);
        lvgamer.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                arrayDadosGamer = new ArrayList<>();

                String nome = arrayGamer.get(position).getNome();
                int idade = arrayGamer.get(position).getIdade();
                String cpf = arrayGamer.get(position).getCpf();
                String email = arrayGamer.get(position).getEmail();
                String telefone = arrayGamer.get(position).getTelefone();
                String uf = arrayGamer.get(position).getUf();
                ArrayList<String> categorias = arrayGamer.get(position).getCategorias();

                arrayDadosGamer.add(nome);
                arrayDadosGamer.add(String.valueOf(idade));
                arrayDadosGamer.add(cpf);
                arrayDadosGamer.add(email);
                arrayDadosGamer.add(telefone);
                arrayDadosGamer.add(uf);

                String cat = "";

                // inicio da caminhada; fim da caminhada; modo de caminhar
                for (int i = 0; i < categorias.size(); i++){
                    if ( i > 0) {
                        if (i == categorias.size()-2)
                            cat += categorias.get(i).toLowerCase() + " e ";

                        else
                        if (i == categorias.size()-1)
                            cat += categorias.get(i).toLowerCase();
                        else
                            cat += categorias.get(i).toLowerCase() + ", ";
                    }
                    else{
                        if (i == categorias.size()-2)
                            cat += categorias.get(i) + " e ";

                        else
                        if (i == categorias.size()-1)
                            cat += categorias.get(i);
                        else
                            cat += categorias.get(i) + ", ";
                    }
                }

                arrayDadosGamer.add(cat);

                intent = new Intent(MainActivity3.this, MainActivity5.class);
                intent.putExtra("dadosGamer", arrayDadosGamer);
                intent.putExtra("refPosicao", position);
                startActivity(intent);
            }
        });

    }

    public void voltar(View View){
        intent = new Intent(MainActivity3.this, MainActivity6.class);
        startActivity(intent);
    }

    }
